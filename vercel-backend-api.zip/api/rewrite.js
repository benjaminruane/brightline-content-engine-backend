import handlerGenerate from './generate';

// We will reuse the same logic but tweak notes as "rewriteNotes"
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(200).end();
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Massage body so generate handler treats rewriteNotes as notes
  const body = req.body || {};
  const notes = body.rewriteNotes
    ? `Revision notes from user:\n${body.rewriteNotes}\n` 
    : (body.notes || '');
  req.body = { ...body, notes };

  return handlerGenerate(req, res);
}
